SDK OpenDOF C
---
This component is a package of opendof libraries, tools, and support components for the c language.

##Use Cases
####Distribution of OpenDOF C libraries
A developer, writing software that uses OpenDOF uses the sdk to access the common C libraries and the library's api documentation.

####Link to OpenDOF C Documentation
A user wanting to learn more about OpenDOF C libraries uses the sdk to read the OpenDOF C documentation.

##Requirements
####Distribute common opendof c libraries
This sdk will distribute the libraries commonly used for OpenDOF C programs.
These libraries include:

- core-c-dof-aes-cipher-plugin
- core-c-dof-cipher-plugins-dev
- core-c-dof-connection-reconnecting-listener
- core-c-dof-inet-posix
- core-c-dof-inet-tls-posix
- core-c-dof-oal
- core-c-dof-pcr-dev
- core-c-dof-pcr-posix
- core-c-dof-sms4-cipher-plugin
- core-c-dof-twofish-cipher-plugin

####Link to OpenDOF training
This sdk will link to the OpenDOF Getting Started Training for C.

####Link to Programmer's guides
The sdk will link to the operations, connectivity, and security programmer’s guides for the C language.

##Installation
To install this sdk expand the contents of this sdk into a directory you have write access and then execute the respective build script as desired for your developement and/or learning. The sdk contains two shell scripts for building all of the Core C source libraries into binaries, you only need to execute one depending on your environment setup. The 'cmake-build' script can be used to build the source libraries into binaries that the host machine executing the buiild script can use. One may execute the script as follows to install the libraries into the default system location:

- `cmake-build`

Or in some cases it may be necessary to specify the install location. The command above can be replaced with the following to change the default install location:

- `cmake-build <path to alternate install location>`

The 'cmake-cross-compile-build' script can be used to cross compile all the Core C source libraries into binaries for a different target system architecture other than the host machine executing the script. In order to do this, the provided 'cmake-toolchain.cmake' file must be editted first before executing the cross compile script. The script itself has instructions provided to help you get started. Please note that the 'cmake-toolchain' file is only a template file, and in no way provides every setting that may be used for various toolchain setups. It is provided for a starting point for creating a toolchain file for cross compiling. Toolchain file setups for various target systems are beyond the scope of this document. The 'cmake-cross-compile-build' script can be executed as follows to install the libraries into the default system location:

- `cmake-cross-compile-build`

Or in some cases it may be necessary to specify the install location. The command above can be replaced with the following to change the default install location:

- `cmake-cross-compile-build <path to alternate install location>`

Once the libraries are built follow the "Training" section below.

##Usage
####Guides
These guides can be located on the OpenDOF website.

- [DOF Connectivity Programmers Guide](https://opendof.org/downloads/dof-connectivity-programmers-guide/)
- [DOF Operations Programmers Guide C](https://opendof.org/downloads/dof-operations-programmers-guide-c/)
- [DOF Security Programmers Guide](https://opendof.org/downloads/dof-security-programmers-guide/)

####Libraries
These libraries can be located in the lib/c directory.

- opendof-aes-cipher-plugin source
- opendof-cipher-plugins-dev source
- opendof-connection-reconnecting-listener source
- opendof-inet-posix source
- opendof-inet-tls-posix source
- opendof-oal-c source
- opendof-pcr-dev source
- opendof-pcr-posix source
- opendof-sms4-cipher-plugin source
- opendof-twofish-cipher-plugin source

####Training
Training for the OpenDOF C libraries can be located on the OpenDOF website.
- [OpenDOF Getting Started C Training](https://opendof.org/docs/getting-started/c).

##How to Report an Issue

Issues can be reported through the issue tracking system of the OpenDOF Project at https://issue.opendof.org

Information on the process for reporting an issue can be found at https://opendof.org/report-an-issue.