#SDK OpenDOF C (training-sdk-sdk-opendof-c-8) Release Information

##Version 1.1.0.7
(2018-01-12, from path "sdk-opendof-c-8" at commit 922ee1beba781190f59f51ee21f5ed0dc1e185bc on branch "master" of repository training-sdk)

This release includes the following additions, updates, and changes:

- Added bash scripts for building all the included libraries and cross-compiling.

More information can be found on this project at [https://opendof.org/](https://opendof.org/)

----------

##Version 1.0.0.4
(2017-07-26, from path "sdk-opendof-c-8" at commit 77630c434a7769b6c8ab6a9409b975bcf4fdd9d0 on branch "master" of repository training-sdk)

This is the initial public release of this project.

More information can be found on this project at [https://opendof.org/](https://opendof.org/)